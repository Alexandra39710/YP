from datetime import timedelta
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.utils import timezone

from catalog.models import Category, Service, ServiceRequest


class Command(BaseCommand):
    help = "Наполняет БД: 4 категории, 15 услуг, 8 заявок."

    def handle(self, *args, **options):
        # Чистим, чтобы повторный запуск не падал на UNIQUE slug
        ServiceRequest.objects.all().delete()
        Service.objects.all().delete()
        Category.objects.all().delete()

        cats = [
            Category.objects.create(name="Обучение", slug="obuchenie"),
            Category.objects.create(name="Консультации", slug="konsultacii"),
            Category.objects.create(name="Тестирование", slug="testirovanie"),
            Category.objects.create(name="Курсы", slug="kursy"),
        ]

        services_data = [
            # (индекс категории, name, description, price, duration_minutes)
            (0, "Подготовка к ЕГЭ (математика)", "90 академ. часов", 12000, 5400),
            (0, "Подготовка к ОГЭ (русский)", "60 академ. часов", 9000, 3600),
            (0, "Английский для начинающих", "Разговорный курс", 8500, 4800),
            (0, "Информатика — базовый курс", "Основы программирования", 10000, 4200),

            (1, "Профориентационная консультация", "60 минут с психологом", 2500, 60),
            (1, "Консультация по поступлению", "Подбор вуза и направления", 1500, 45),
            (1, "Карьерная консультация", "Помощь с резюме", 2000, 60),
            (1, "Консультация родителей", "Вопросы обучения детей", 1800, 45),

            (2, "Профориентационный тест", "Тест Голланда", 1200, 40),
            (2, "Тест на IQ", "Стандартизированный тест", 1500, 60),
            (2, "Психологическое тестирование", "Комплексное", 2200, 90),
            (2, "Лингвистический тест", "Определение уровня", 900, 30),

            (3, "Python-разработчик", "Базовый курс, 3 месяца", 25000, 7200),
            (3, "Excel для офиса", "Продвинутый уровень", 4500, 1800),
            (3, "Веб-дизайн", "Figma + основы UX", 18000, 5400),
        ]

        services = []
        for cat_idx, name, desc, price, dur in services_data:
            services.append(Service.objects.create(
                category=cats[cat_idx],
                name=name,
                description=desc,
                price=Decimal(price),
                duration_minutes=dur,
                is_available=True,
            ))

        # Одна услуга недоступна — нужна для теста "заявка на недоступную услугу"
        services[0].is_available = False
        services[0].save()

        now = timezone.now()
        requests_data = [
            (services[1], "Иванов Иван", "+79990000001", 2, "new"),
            (services[2], "Петрова Анна", "+79990000002", 3, "confirmed"),
            (services[3], "Сидоров Пётр", "+79990000003", 5, "new"),
            (services[4], "Кузнецова Мария", "+79990000004", 7, "new"),
            (services[5], "Смирнов Олег", "+79990000005", 1, "cancelled"),
            (services[9], "Волкова Ольга", "+79990000006", 4, "done"),
            (services[12], "Морозов Денис", "+79990000007", 6, "new"),
            (services[13], "Новикова Елена", "+79990000008", 8, "confirmed"),
        ]
        for svc, name, phone, days, st in requests_data:
            ServiceRequest.objects.create(
                service=svc,
                client_name=name,
                phone=phone,
                desired_at=now + timedelta(days=days),
                status=st,
            )

        self.stdout.write(self.style.SUCCESS(
            f"Создано: {Category.objects.count()} категорий, "
            f"{Service.objects.count()} услуг, "
            f"{ServiceRequest.objects.count()} заявок."
        ))
