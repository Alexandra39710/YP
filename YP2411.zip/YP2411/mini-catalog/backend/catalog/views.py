from datetime import timedelta

from django.db.models import Count
from django.utils import timezone
from rest_framework import viewsets, mixins
from rest_framework.decorators import action
from rest_framework.permissions import (
    AllowAny, IsAdminUser, SAFE_METHODS, BasePermission,
)
from rest_framework.response import Response
from rest_framework.views import APIView

from .filters import ServiceFilter
from .models import Category, Service, ServiceRequest
from .serializers import (
    CategorySerializer, ServiceSerializer, ServiceDetailSerializer,
    ServiceRequestSerializer,
)


class IsAdminOrReadOnly(BasePermission):
    """Чтение — всем, изменения — только администратору."""
    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return True
        return bool(request.user and request.user.is_staff)


class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsAdminOrReadOnly]
    lookup_field = "slug"
    search_fields = ["name"]


class ServiceViewSet(viewsets.ModelViewSet):
    queryset = Service.objects.select_related("category").all()
    serializer_class = ServiceSerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_class = ServiceFilter
    search_fields = ["name", "description"]
    ordering_fields = ["price", "created_at", "name"]
    ordering = ["-created_at"]

    def get_serializer_class(self):
        if self.action == "retrieve":
            return ServiceDetailSerializer
        return ServiceSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        if not (self.request.user and self.request.user.is_staff):
            qs = qs.filter(is_available=True)
        return qs

    @action(detail=False, methods=["get"],
            url_path="by-category/(?P<slug>[-\w]+)")
    def by_category(self, request, slug=None):
        qs = self.get_queryset().filter(category__slug=slug)
        page = self.paginate_queryset(qs)
        serializer = ServiceSerializer(
            page, many=True, context={"request": request}
        )
        return self.get_paginated_response(serializer.data)


class ServiceRequestViewSet(
    mixins.CreateModelMixin,
    mixins.RetrieveModelMixin,
    mixins.ListModelMixin,
    viewsets.GenericViewSet,
):
    queryset = ServiceRequest.objects.select_related("service").all()
    serializer_class = ServiceRequestSerializer

    def get_permissions(self):
        if self.action == "create":
            return [AllowAny()]
        return [IsAdminUser()]

    def get_queryset(self):
        qs = super().get_queryset()
        if not (self.request.user and self.request.user.is_staff):
            return qs.none()
        return qs

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save(status=ServiceRequest.Status.NEW)
        return Response(serializer.data, status=201)


class StatisticsView(APIView):
    """Статистика: услуги по категориям + заявки за неделю."""
    permission_classes = [AllowAny]

    def get(self, request):
        categories = (
            Category.objects
            .annotate(services_count=Count("services"))
            .values("id", "name", "slug", "services_count")
            .order_by("name")
        )
        week_ago = timezone.now() - timedelta(days=7)
        new_requests = ServiceRequest.objects.filter(
            created_at__gte=week_ago
        ).count()
        return Response({
            "categories": list(categories),
            "new_requests_last_week": new_requests,
        })
