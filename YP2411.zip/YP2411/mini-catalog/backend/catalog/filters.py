import django_filters

from .models import Service


class ServiceFilter(django_filters.FilterSet):
    category = django_filters.CharFilter(field_name="category__slug")
    is_available = django_filters.BooleanFilter(field_name="is_available")
    min_price = django_filters.NumberFilter(field_name="price", lookup_expr="gte")
    max_price = django_filters.NumberFilter(field_name="price", lookup_expr="lte")

    class Meta:
        model = Service
        fields = ["category", "is_available", "min_price", "max_price"]
