from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import (
    CategoryViewSet,
    ServiceViewSet,
    ServiceRequestViewSet,
    StatisticsView,
)

router = DefaultRouter()
router.register("categories", CategoryViewSet, basename="category")
router.register("services", ServiceViewSet, basename="service")
router.register("requests", ServiceRequestViewSet, basename="request")

urlpatterns = [
    path("stats/", StatisticsView.as_view(), name="stats"),
    path("", include(router.urls)),
]
