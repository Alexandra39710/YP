from django.utils import timezone
from rest_framework import serializers

from .models import Category, Service, ServiceRequest


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ["id", "name", "slug"]


class ServiceSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source="category.name", read_only=True)

    class Meta:
        model = Service
        fields = [
            "id", "category", "category_name", "name", "description",
            "price", "duration_minutes", "is_available", "created_at",
        ]
        read_only_fields = ["id", "created_at", "category_name"]

    def validate_price(self, value):
        if value < 0:
            raise serializers.ValidationError("Цена не может быть отрицательной.")
        return value

    def validate_duration_minutes(self, value):
        if value <= 0:
            raise serializers.ValidationError("Длительность должна быть > 0.")
        return value


class ServiceDetailSerializer(ServiceSerializer):
    category = CategorySerializer(read_only=True)

    class Meta(ServiceSerializer.Meta):
        fields = ServiceSerializer.Meta.fields


class ServiceRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = ServiceRequest
        fields = [
            "id", "service", "client_name", "phone",
            "desired_at", "status", "created_at",
        ]
        read_only_fields = ["id", "status", "created_at"]

    def validate_phone(self, value):
        cleaned = (value or "").strip()
        if not cleaned:
            raise serializers.ValidationError("Телефон обязателен.")
        if len(cleaned) < 5:
            raise serializers.ValidationError("Телефон слишком короткий.")
        return cleaned

    def validate_desired_at(self, value):
        if value <= timezone.now():
            raise serializers.ValidationError(
                "Желаемое время должно быть в будущем."
            )
        return value

    def validate_service(self, value):
        if not value.is_available:
            raise serializers.ValidationError("Услуга недоступна для заявки.")
        return value
