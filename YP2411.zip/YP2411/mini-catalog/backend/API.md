# API — Mini Catalog

Документация REST API серверной части учебного каталога услуг
(УП.05, задание № 1).

## Базовый URL

```
http://127.0.0.1:8000/api/
```

Формат данных — `application/json; charset=utf-8`.
Даты — ISO 8601 (`2026-12-01T10:00:00Z`).

## Права доступа

| Роль | Как получить | Что может |
|---|---|---|
| Аноним | без авторизации | читать категории и доступные услуги; создавать заявки |
| Администратор | сессия Django (`/admin/`) | всё, включая изменения категорий, услуг и просмотр заявок |

- Чтение (`GET`) категорий и услуг — всем.
- Изменение (`POST`, `PATCH`, `PUT`, `DELETE`) категорий и услуг — только администратору (иначе 401/403).
- Создание заявки (`POST /requests/`) — всем.
- Просмотр заявок (`GET /requests/`, `GET /requests/{id}/`) — только администратору.

## Эндпоинты

### Категории — `/api/categories/`

| Метод | URL | Доступ | Описание |
|---|---|---|---|
| GET | `/api/categories/` | все | список категорий |
| POST | `/api/categories/` | админ | создать категорию |
| GET | `/api/categories/{slug}/` | все | одна категория |
| PUT/PATCH | `/api/categories/{slug}/` | админ | изменить |
| DELETE | `/api/categories/{slug}/` | админ | удалить |

Идентификатор — `slug` (уникальный), а не `id`.

Поля:
- `id` — число, только чтение
- `name` — строка, обязательное
- `slug` — строка, уникальная, обязательное

Пример — `GET /api/categories/`

```json
{
  "count": 4,
  "next": null,
  "previous": null,
  "results": [
    {"id": 1, "name": "Обучение", "slug": "obuchenie"},
    {"id": 2, "name": "Консультации", "slug": "konsultacii"},
    {"id": 3, "name": "Тестирование", "slug": "testirovanie"},
    {"id": 4, "name": "Курсы", "slug": "kursy"}
  ]
}
```

---

### Услуги — `/api/services/`

| Метод | URL | Доступ | Описание |
|---|---|---|---|
| GET | `/api/services/` | все | список опубликованных услуг |
| POST | `/api/services/` | админ | создать услугу |
| GET | `/api/services/{id}/` | все | детали + название категории |
| PUT/PATCH | `/api/services/{id}/` | админ | изменить |
| DELETE | `/api/services/{id}/` | админ | удалить |
| GET | `/api/services/by-category/{slug}/` | все | услуги выбранной категории |

Аноним видит только услуги с `is_available=true`.
Администратор — все.

Поля:
- `id` — число, только чтение
- `category` — id категории, обязательное
- `category_name` — строка, только чтение (есть в retrieve и в списке)
- `name` — строка, обязательное
- `description` — строка, может быть пустой
- `price` — число (Decimal), `>= 0`, обязательное
- `duration_minutes` — целое, `> 0`, обязательное
- `is_available` — bool, по умолчанию true
- `created_at` — дата-время, только чтение

#### Query-параметры для `GET /api/services/`

| Параметр | Тип | Пример | Назначение |
|---|---|---|---|
| `category` | slug | `obuchenie` | фильтр по категории |
| `is_available` | bool | `true` / `false` | фильтр по доступности |
| `min_price` | число | `1000` | цена `>= min_price` |
| `max_price` | число | `15000` | цена `<= max_price` |
| `search` | строка | `python` | поиск по name и description |
| `ordering` | строка | `price`, `-price`, `name`, `created_at` | сортировка |
| `page` | число | `1`, `2`, … | номер страницы |

Пагинация — по 5 записей.

Пример — `GET /api/services/?page=1`

```json
{
  "count": 14,
  "next": "http://127.0.0.1:8000/api/services/?page=2",
  "previous": null,
  "results": [
    {
      "id": 2,
      "category": 1,
      "category_name": "Обучение",
      "name": "Подготовка к ОГЭ (русский)",
      "description": "60 академ. часов",
      "price": "9000.00",
      "duration_minutes": 3600,
      "is_available": true,
      "created_at": "2026-11-24T10:15:33.482Z"
    }
  ]
}
```

Пример — составной фильтр + сортировка

```
GET /api/services/?category=obuchenie&min_price=5000&max_price=15000&ordering=-price
```

Пример — поиск

```
GET /api/services/?search=python
```

Пример — `GET /api/services/2/` (детали)

```json
{
  "id": 2,
  "category": {"id": 1, "name": "Обучение", "slug": "obuchenie"},
  "category_name": "Обучение",
  "name": "Подготовка к ОГЭ (русский)",
  "description": "60 академ. часов",
  "price": "9000.00",
  "duration_minutes": 3600,
  "is_available": true,
  "created_at": "2026-11-24T10:15:33.482Z"
}
```

В retrieve поле `category` — вложенный объект, в списке — число id.

Пример — `GET /api/services/by-category/obuchenie/`

Формат совпадает с форматом списка (пагинация по 5, поля как у ServiceSerializer), но только услуги указанной категории.

---

### Заявки — `/api/requests/`

| Метод | URL | Доступ | Описание |
|---|---|---|---|
| POST | `/api/requests/` | все | создать заявку |
| GET | `/api/requests/` | админ | список заявок |
| GET | `/api/requests/{id}/` | админ | одна заявка |

Поля:
- `id` — число, только чтение
- `service` — id услуги, обязательное
- `client_name` — строка, обязательное
- `phone` — строка, обязательное, непустое, минимум 5 символов
- `desired_at` — дата-время, обязательное, в будущем
- `status` — `new | confirmed | done | cancelled`, только чтение; сервер ставит new
- `created_at` — только чтение

Пример — `POST /api/requests/`

```json
{
  "service": 2,
  "client_name": "Иван",
  "phone": "+79990000000",
  "desired_at": "2026-12-01T10:00:00Z"
}
```

Ответ `201 Created`:

```json
{
  "id": 9,
  "service": 2,
  "client_name": "Иван",
  "phone": "+79990000000",
  "desired_at": "2026-12-01T10:00:00Z",
  "status": "new",
  "created_at": "2026-11-24T10:20:11.111Z"
}
```

---

### Статистика — `/api/stats/` (дополнительное задание)

| Метод | URL | Доступ | Описание |
|---|---|---|---|
| GET | `/api/stats/` | все | количество услуг по категориям + новых заявок за 7 дней |

Пример — `GET /api/stats/`

```json
{
  "categories": [
    {"id": 1, "name": "Обучение", "slug": "obuchenie", "services_count": 4},
    {"id": 2, "name": "Консультации", "slug": "konsultacii", "services_count": 4},
    {"id": 3, "name": "Тестирование", "slug": "testirovanie", "services_count": 4},
    {"id": 4, "name": "Курсы", "slug": "kursy", "services_count": 3}
  ],
  "new_requests_last_week": 8
}
```

---

## Бизнес-правила (проверяются сервером)

| Правило | Где срабатывает | Код ответа |
|---|---|---|
| price >= 0 | POST/PATCH /services/ | 400 |
| duration_minutes > 0 | POST/PATCH /services/ | 400 |
| category.slug уникален | POST/PATCH /categories/ | 400 |
| desired_at в будущем | POST /requests/ | 400 |
| Услуга должна быть is_available=true | POST /requests/ | 400 |
| phone не пустой (>= 5 символов) | POST /requests/ | 400 |
| status новой заявки — new | POST /requests/ | ставится сервером |
| Аноним не меняет услуги/категории | POST/PATCH/PUT/DELETE | 401/403 |
| Аноним не видит заявки | GET /requests/ | пустой список |
| Несуществующий service_id | POST /requests/ | 400 |
| Несуществующий slug/id | GET .../{id}/ | 404 |
| Некорректные query-параметры (min_price=abc) | GET /services/ | 400 |

## Формат ошибок

400 Bad Request — ошибки валидации:

```json
{
  "desired_at": ["Желаемое время должно быть в будущем."],
  "service": ["Услуга недоступна для заявки."],
  "phone": ["Телефон обязателен."]
}
```

401 Unauthorized / 403 Forbidden:

```json
{"detail": "Authentication credentials were not provided."}
```

404 Not Found:

```json
{"detail": "No Service matches the given query."}
```

## Коды ответов

| Код | Когда |
|---|---|
| 200 OK | успешный GET/PATCH/PUT |
| 201 Created | успешный POST |
| 204 No Content | успешный DELETE |
| 400 Bad Request | ошибка валидации, некорректный query-параметр |
| 401 Unauthorized | требуется авторизация |
| 403 Forbidden | нет прав (аноним пытается изменить данные) |
| 404 Not Found | объект не найден |

## Примеры через curl

```bash
# список услуг (страница 1)
curl -s "http://127.0.0.1:8000/api/services/?page=1"

# фильтр + сортировка
curl -s "http://127.0.0.1:8000/api/services/?category=obuchenie&min_price=5000&max_price=15000&ordering=-price"

# поиск
curl -s "http://127.0.0.1:8000/api/services/?search=python"

# услуги категории
curl -s "http://127.0.0.1:8000/api/services/by-category/obuchenie/"

# детали услуги
curl -s "http://127.0.0.1:8000/api/services/2/"

# статистика
curl -s "http://127.0.0.1:8000/api/stats/"

# создать заявку
curl -X POST "http://127.0.0.1:8000/api/requests/" \
  -H "Content-Type: application/json" \
  -d '{"service":2,"client_name":"Иван","phone":"+79990000000","desired_at":"2026-12-01T10:00:00Z"}'

# изменить услугу (нужна сессия админа — иначе 403)
curl -X PATCH "http://127.0.0.1:8000/api/services/2/" \
  -H "Content-Type: application/json" \
  -d '{"price":"9500.00"}'
```

## Где смотреть интерактивно

DRF предоставляет браузерный интерфейс для всех эндпоинтов:

```
http://127.0.0.1:8000/api/
```

Через него можно выполнять GET/POST/PATCH/DELETE, если залогинен администратор (`/admin/`).